import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class IngredientsService {

  url:string ="http://localhost:7000/";
  constructor(private http: HttpClient) { }


    //http://localhost:7000/fetchAllIngredients

    fetchAllIngredients()
    {
      return this.http.get(this.url+"fetchAllIngredients");
    }

  
 //http://localhost:7000/fetchAllPizzas

 fetchAllPizzas(){
  return this.http.get(this.url+"fetchAllPizzas");
 }

//http://localhost:7000/insertdata/?id=6&&type=veg&&price=230&&name=Pizza&&image=https://thumb7.shutterstock.com/display_pic_with_logo/96886/96886,1274350207,7/stock-photo-pizza-53553874.jpg
 insertdata(id:number ,type:string , price:number,name:string , image:string)
 {

  return this.http.get(this.url+"insertdata/?id="+id+"&&type="+type+"&&price="+price+"&&name="+name+"&&image="+image);
 }

 fetchShoppingcart() {
  return this.http.get(this.url+"fetchShoppingcart");
 }

 updatequantity(id:number,quantity:number){
  return this.http.get(this.url+"updatequantity/?id="+id+"&&quantity="+quantity);
}




deleteCartItems(id:number){
  return this.http.get(this.url+"deletedata/?id="+id)
}
}



