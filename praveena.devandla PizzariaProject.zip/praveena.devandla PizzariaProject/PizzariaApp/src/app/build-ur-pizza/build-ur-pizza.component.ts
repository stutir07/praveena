import { Component, OnInit } from '@angular/core';
import { IngredientsService } from '../ingredients.service';

@Component({
  selector: 'app-build-ur-pizza',
  templateUrl: './build-ur-pizza.component.html',
  styleUrls: ['./build-ur-pizza.component.css']
})
export class BuildUrPizzaComponent implements OnInit {
ingredients:any;
totalcost:number =0;
constructor(private i:IngredientsService){

}
ngOnInit(){
  this.i.fetchAllIngredients().subscribe((ingredientsdata)=>{
    this.ingredients = ingredientsdata;
  });
}

updateTotal(item: any,event:any):void{
  if(event.target.checked){
    this.totalcost += item.price;
  } else {
    this.totalcost -= item.price;
  }
}
}
