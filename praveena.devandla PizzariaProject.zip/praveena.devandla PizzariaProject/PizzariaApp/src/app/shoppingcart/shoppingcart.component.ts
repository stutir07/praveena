import { Component} from '@angular/core';
import { IngredientsService } from '../ingredients.service';


@Component({
  selector: 'app-shoppingcart',
  templateUrl: './shoppingcart.component.html',
  styleUrls: ['./shoppingcart.component.css']
})
export class ShoppingcartComponent  {


  cartitems : any;
  totalcost:number=0
 
 
  constructor(private ps:IngredientsService){
   
    this.fetchdata()
    
    }
    fetchdata(){
      this.ps.fetchShoppingcart().subscribe((items)=>{
        this.cartitems = items;
        console.log('Updated cart items:', this.cartitems)
        this.updateTotalCost();
    })

    }
    deleteItem(id:number) {
      this.ps.deleteCartItems(id).subscribe(()=>{
        alert("Item deleted successfully");
        this.fetchdata()
       
      })
    }

    incrementitem(pid:number,quantity:number) {
      console.log(pid, quantity)
      quantity = quantity + 1;
      this.ps.updatequantity(pid,quantity).subscribe(()=>{
        this.fetchdata();
     
       
      })
    }
     
    decrementitem(pid:number,quantity:number) {
      if (quantity < 2){
        quantity = 1
      }
      else {
      quantity = quantity - 1;
      this.ps.updatequantity(pid,quantity).subscribe(()=>{
        this.fetchdata();
      })
     


      }
    }
      updateTotalCost() {
        this.totalcost=0;
        console.log("Show cost",this.totalcost);
        this.totalcost = this.cartitems.reduce((sum:number, item:any) => {
          console.log("Total",this.totalcost);
          return sum + (item.price * item.quantity);
        }, 0);
        
      }}
    
  
  




  



    






