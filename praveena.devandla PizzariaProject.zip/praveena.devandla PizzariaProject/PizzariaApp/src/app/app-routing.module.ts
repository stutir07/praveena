import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { BuildUrPizzaComponent } from './build-ur-pizza/build-ur-pizza.component';
import { OrderComponent } from './order/order.component';
import { ShoppingcartComponent } from './shoppingcart/shoppingcart.component';


const routes: Routes = [
 {path:'',component:HomeComponent},
  {path:'home', component:HomeComponent},
  {path:'build',component:BuildUrPizzaComponent},
  {path:'order', component:OrderComponent},
  {path:'addtocart', component:ShoppingcartComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
