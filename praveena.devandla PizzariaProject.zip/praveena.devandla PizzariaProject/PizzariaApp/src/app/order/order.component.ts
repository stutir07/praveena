import { Component, OnInit } from '@angular/core';
import { IngredientsService } from '../ingredients.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
  pizzas:any;
  
  constructor(private p:IngredientsService, private router:Router){

  }

  ngOnInit() {
    this.p.fetchAllPizzas().subscribe((pizzadata)=>{
     this.pizzas = pizzadata;
     console.log(this.pizzas)
    })
  }

  addToCart(pid: number){
    for(let item of this.pizzas){
      if(item.id==pid){
        console.log(item);
        this.p.insertdata(item.id, item.type, item.price, item.name, item.image).subscribe(()=>{
          alert("Data Inserted succesfully!!");
          //  this.router.navigate(['build']);
        })
      }

      

    }

  }

}
