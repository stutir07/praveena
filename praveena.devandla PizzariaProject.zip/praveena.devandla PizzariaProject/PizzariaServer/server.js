let express = require('express');
let mongodb = require('mongodb');
let cors = require('cors')
let app = express();
let mongoclient = mongodb.MongoClient;
app.use(cors());
let url = "mongodb://127.0.0.1:27017";
let dbName = "PizzaData";


//http://localhost:7000/fetchAllPizzas
app.get('/fetchAllPizzas',(req,res)=>{
    mongoclient.connect(url,(error,conn)=>{
        if(error){
            console.log("DB Connectivity UnSuccessful...")
        }else{
            console.log("DB Connectivity Successful...")
            let db = conn.db(dbName);
            db.collection('pizza').find().toArray((error,pizzadata)=>{
            if(error){
                console.log("some error, Pizza Data could not be fetched")
            }else{
                res.json(pizzadata);
            }
            res.end();
            conn.close();
        })
        }
    })
});


//http://localhost:7000/fetchAllIngredients
app.get('/fetchAllIngredients',(req,res)=>{
    mongoclient.connect(url,(error,conn)=>{
        if(error){
            console.log("DB Connectivity UnSuccessful...")
        }else{
            console.log("DB Connectivity Successful...")
            let db = conn.db(dbName);
            db.collection('ingredients').find().toArray((error,ingredientsdata)=>{
            if(error){
                console.log("some error, ingredients Data could not be fetched")
            }else{
                res.json(ingredientsdata);
            }
            res.end();
            conn.close();
        })
        }
    })
})






//http://localhost:7000/fetchShoppingcart
app.get('/fetchShoppingcart',(req,res)=>{
    mongoclient.connect(url,(error,conn)=>{
        if(error){
            console.log("DB Connectivity UnSuccessful...")
        }else{
            console.log("DB Connectivity Successful...")
            let db = conn.db(dbName);
            db.collection('shoppingcart').find().toArray((error,shoppingcartdata)=>{
            if(error){
                console.log("some error, shopping cart could not be fetched")
            }else{
                res.json(shoppingcartdata);
            }
            res.end();
            conn.close();
        })
        }
    })
});

//http://localhost:7000/insertdata/?id=6&&type=veg&&price=230&&name=Pizza&&image=https://thumb7.shutterstock.com/display_pic_with_logo/96886/96886,1274350207,7/stock-photo-pizza-53553874.jpg
app.get('/insertdata',(req,res)=>{
    console.log("Shopping Cart data to be Inserted = ",req.query);
    mongoclient.connect(url,(error, conn)=>{
        if(error){
            console.log("DB Connectivity UnSuccessful....");
        }
        else{
            console.log("DB connectivity Successful...")
            let db = conn.db(dbName);
            let data ={

            id:req.query.id,
            type:req.query.type,
            price:req.query.price,
            name:req.query.name,
            image:req.query.image,
            quantity: 1
            };

            db.collection('shoppingcart').insertOne(data, (error,s)=>{
                if(error)
                    {
                        res.json({message:"Some Error ,  Data Could not be Saved..."});
                    }
                    else
                    {
                        res.json({message:" Data  Saved Successfully..."});
                    }
                    res.end();
                    conn.close();

            })

            }
        })
    });


    //http://localhost:7000/deletedata?id=6
    app.get('/deletedata', (req,res)=>{
        console.log("Shopping cart data is deleted= ", req.query);
        mongoclient.connect(url,(error, conn)=>{
            if(error){
                console.log("DB Connectivity Unsuccessful...");

            }else{
                console.log("DB Connectivity Successful...");
                let db = conn.db(dbName);
                let id = (req.query.id);
                db.collection('shoppingcart').deleteOne({ id: id }, (error, result) => {
                    if (error) {
                        res.json({ message: "Some Error, Data Could not be Deleted..." });
                    } else {
                        if (result.deletedCount === 0) {
                            res.json({ message: "No matching item found to delete." });
                        } else {
                            res.json({ message: "Data Deleted Successfully..." });
                        }
                    }
                    res.end();
                    conn.close();
                });
            }
        });
    })

       // quantity

        app.get('/updatequantity', (req,res)=>{
            
            mongoclient.connect(url,(error, conn)=>{
                if(error){
                    console.log("DB Connectivity Unsuccessful...");
    
                }else{
                    console.log("DB Connectivity Successful...");
                    let db = conn.db(dbName);
                    let id = req.query.id;
                    db.collection('shoppingcart').updateOne({ id: id} , {$set:{quantity:parseInt(req.query.quantity)}},(error, result) => {
                        if (error) {
                            res.json({ message: "Some Error, Data Could not be Deleted..." });
                        } else {
                          
                                res.json({ message: "Data Updated Successfully..." });
                            
                        }
                        res.end();
                        conn.close();
                    });
                }
            });
        })
        


       

  
app.listen(7000,()=>{
    console.log("express server running on port 7000.....")
});