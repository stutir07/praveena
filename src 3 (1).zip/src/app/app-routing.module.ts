import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SearchemployeeComponent } from './searchemployee/searchemployee.component';
import { RegisteremployeeComponent } from './registeremployee/registeremployee.component';
import { ListemployeeComponent } from './listemployee/listemployee.component';

const routes: Routes = [
  {path:'searchemployee',component:SearchemployeeComponent},
  {path:'registeremployee',component:RegisteremployeeComponent},
  {path:'listemployee',component:ListemployeeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
