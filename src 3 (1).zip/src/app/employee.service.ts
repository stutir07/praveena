import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  url:string = "http://localhost:7000/";
  constructor(private http:HttpClient) { }


  // http://localhost:7000/searchemployee/?empno=1231
 SearchEmployee(empno:number)
 {
    return this.http.get(this.url+"searchemployee/?empno="+empno);
 }


 //http://localhost:7000/?empno=1244&empname=Thangaraj&age=44&salary=56789
 SaveEmployee(eno:number , ename:string , a:number , sal:number)
 {

  return this.http.get(this.url+"saveemployee/?empno="+eno+"&empname="+ename+"&age="+a+"&salary="+sal);
 }


 FetchAllEmployees()
 {
  return this.http.get(this.url+"listemployees");
 }
}
