import { Component } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-searchemployee',
  templateUrl: './searchemployee.component.html',
  styleUrls: ['./searchemployee.component.css']
})
export class SearchemployeeComponent {
empno:number=0;
employee:any;
constructor(private es:EmployeeService){

}
SearchEmployee()
{
  this.es.SearchEmployee(this.empno).subscribe((employee)=>{
    this.employee = employee;
  })
}
}
