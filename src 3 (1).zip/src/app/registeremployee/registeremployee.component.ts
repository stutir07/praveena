import { Component } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-registeremployee',
  templateUrl: './registeremployee.component.html',
  styleUrls: ['./registeremployee.component.css']
})
export class RegisteremployeeComponent {
empno:number=0;
empname:string='';
age:number=0;
salary:number=0;
R:any;
constructor(private es:EmployeeService)
{

}
SaveEmployee()
{
  console.log("Employee No =",this.empno);
  console.log("Employee Name =",this.empname);
  console.log("Employee Age =",this.age);
  console.log("Employee Salary =",this.salary);
    this.es.SaveEmployee(this.empno,this.empname,this.age,this.salary).subscribe((result)=>{
      this.R = result;
    })
}


}
