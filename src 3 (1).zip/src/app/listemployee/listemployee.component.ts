import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-listemployee',
  templateUrl: './listemployee.component.html',
  styleUrls: ['./listemployee.component.css']
})
export class ListemployeeComponent implements OnInit{

  employees:any;
  constructor(private es:EmployeeService){

  }

  ngOnInit()
  {
    this.es.FetchAllEmployees().subscribe((empsdata)=>{
      this.employees = empsdata;
    })
  }

}
